#include <string.h>
#include <stdio.h>

#define PRINT(...) do { \
        printf("[P%d] ", XM_PARTITION_SELF); \
        printf(__VA_ARGS__); \
} while (0)

int PartitionMain(void)
{
	while(1)
	{
		PRINT("------------------------\n");
		PRINT("---PARTITION1---\n");
	}	
	return 0;
}

