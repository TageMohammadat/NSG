#include <stdio.h>
#include "xparameters.h"
#include "xgpiops.h"

static XGpioPs mio_emio_pmod2;

#define LED_DELAY 	10000000
#define EMIO_54 	54
#define EMIO_55 	55
#define EMIO_56 	56
#define EMIO_57 	57
#define EMIO_58 	58
#define EMIO_59 	59
#define EMIO_60 	60
#define EMIO_61 	61
#define EMIO_62 	62
#define EMIO_63 	63

int main(void)
{
	int Delay,leer,push;
	XGpioPs_Config *ConfigPtrPS;


    xil_printf("Hello Zynq MIO EMIO AXI GPIO\n\r");

	ConfigPtrPS = XGpioPs_LookupConfig(0);
	XGpioPs_CfgInitialize(&mio_emio_pmod2, ConfigPtrPS, ConfigPtrPS->BaseAddr);

	XGpioPs_SetDirectionPin(&mio_emio_pmod2, EMIO_54, 1);
    XGpioPs_SetOutputEnablePin(&mio_emio_pmod2, EMIO_54, 1);
    XGpioPs_SetDirectionPin(&mio_emio_pmod2, EMIO_55, 1);
    XGpioPs_SetOutputEnablePin(&mio_emio_pmod2, EMIO_55, 1);
    XGpioPs_SetDirectionPin(&mio_emio_pmod2, EMIO_56, 1);
    XGpioPs_SetOutputEnablePin(&mio_emio_pmod2, EMIO_56, 1);
    XGpioPs_SetDirectionPin(&mio_emio_pmod2, EMIO_57, 1);
    XGpioPs_SetOutputEnablePin(&mio_emio_pmod2, EMIO_57, 1);
	XGpioPs_SetDirectionPin(&mio_emio_pmod2, EMIO_58, 1);
    XGpioPs_SetOutputEnablePin(&mio_emio_pmod2, EMIO_58, 1);
	XGpioPs_SetDirectionPin(&mio_emio_pmod2, EMIO_59, 1);
    XGpioPs_SetOutputEnablePin(&mio_emio_pmod2, EMIO_59, 1);
	XGpioPs_SetDirectionPin(&mio_emio_pmod2, EMIO_60, 1);
    XGpioPs_SetOutputEnablePin(&mio_emio_pmod2, EMIO_60, 1);
	XGpioPs_SetDirectionPin(&mio_emio_pmod2, EMIO_61, 1);
    XGpioPs_SetOutputEnablePin(&mio_emio_pmod2, EMIO_61, 1);
	XGpioPs_SetDirectionPin(&mio_emio_pmod2, EMIO_62, 0);
    XGpioPs_SetOutputEnablePin(&mio_emio_pmod2, EMIO_62, 1);
	XGpioPs_SetDirectionPin(&mio_emio_pmod2, EMIO_63, 0);
    XGpioPs_SetOutputEnablePin(&mio_emio_pmod2, EMIO_63, 1);

    XGpioPs_WritePin(&mio_emio_pmod2, EMIO_54, 0x0);
	XGpioPs_WritePin(&mio_emio_pmod2, EMIO_55, 0x0);
	XGpioPs_WritePin(&mio_emio_pmod2, EMIO_56, 0x0);
	XGpioPs_WritePin(&mio_emio_pmod2, EMIO_57, 0x0);
	XGpioPs_WritePin(&mio_emio_pmod2, EMIO_58, 0x0);
	XGpioPs_WritePin(&mio_emio_pmod2, EMIO_59, 0x0);
	XGpioPs_WritePin(&mio_emio_pmod2, EMIO_60, 0x0);
	XGpioPs_WritePin(&mio_emio_pmod2, EMIO_61, 0x0);

    while (1) {
    		leer=XGpioPs_ReadPin(&mio_emio_pmod2,EMIO_62);
    		push=XGpioPs_ReadPin(&mio_emio_pmod2,EMIO_63);


    		if (leer)
    		{
    			XGpioPs_WritePin(&mio_emio_pmod2, EMIO_54, 0x1);
    			XGpioPs_WritePin(&mio_emio_pmod2, EMIO_55, 0x1);
    			XGpioPs_WritePin(&mio_emio_pmod2, EMIO_56, 0x1);
    			XGpioPs_WritePin(&mio_emio_pmod2, EMIO_57, 0x1);
    			XGpioPs_WritePin(&mio_emio_pmod2, EMIO_58, 0x1);
    			XGpioPs_WritePin(&mio_emio_pmod2, EMIO_59, 0x1);
    			XGpioPs_WritePin(&mio_emio_pmod2, EMIO_60, 0x1);
    			XGpioPs_WritePin(&mio_emio_pmod2, EMIO_61, 0x1);
    		}
    		else
    		{
				if (push)
				{
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_54, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_55, 0x1);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_56, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_57, 0x1);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_58, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_59, 0x1);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_60, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_61, 0x1);
				}
				else
				{
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_54, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_55, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_56, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_57, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_58, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_59, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_60, 0x0);
					XGpioPs_WritePin(&mio_emio_pmod2, EMIO_61, 0x0);
				}
    		}

    		//xil_printf("Hello Zynq MIO EMIO AXI GPIO\n\r");

    }
    return 0;
}

